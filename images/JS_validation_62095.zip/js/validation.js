function validateName(name) {
  if (name == "" || name.length < 3 || name.length > 10) {
    document.getElementById("nameError").innerHTML = "Error! Name should be between 3 and 10 symbols!";
    return false;
  } else if (!/^([а-яА-Яѝa-zA-Z0-9_]+)$/.test(name)) {
    document.getElementById("nameError").innerHTML = "Error! Name should contain only letters, numbers and _";
    return false;
  }
  document.getElementById("nameError").innerHTML = "";
  return true;
}

function validatePassword(password) {
  if (password == "" || password.length < 6) {
    document.getElementById("passwordError").innerHTML = "Error! Password should be at least 6 symbols!";
    return false;
  }
  else if (!/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])/.test(password)) {
    document.getElementById("passwordError").innerHTML = "Error! Password should contain 1 uppercase letter, 1 lowercase and 1 digit. ";
    return false;
  }
  document.getElementById("passwordError").innerHTML = "";
  return true;
}

function validateRepeatPassword(password, repeat_password) {
  if (repeat_password == "" || repeat_password != password) {
    document.getElementById("repeatPasswordError").innerHTML = "Error! Password doesn't match!";
    return false;
  }
  document.getElementById("repeatPasswordError").innerHTML = "";
  return true;
}

function validate() {
  var name = document.forms["myform"]["name"].value;
  var password = document.forms["myform"]["password"].value;
  var repeat_password = document.forms["myform"]["repeat_password"].value;

  var nameResult = validateName(name);
  var passwordResult = validatePassword(password)
  var repeat_passwordResult = validateRepeatPassword(password, repeat_password);

  return nameResult && passwordResult && repeat_passwordResult;
}